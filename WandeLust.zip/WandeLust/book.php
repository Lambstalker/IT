<?php 
$con = mysqli_connect("localhost","root","12345","puee");
session_start();
?>
<?php
$u=$_SESSION["username"];
$q="SELECT * from login";
$re=mysqli_query($con, $q);
$row = mysqli_fetch_array($re);
$q1="SELECT * from book";
$re1=mysqli_query($con, $q1);
$row1 = mysqli_fetch_array($re1);
if($row[2]==0 && $row1[0]>30){

$query = "UPDATE login SET book=1 WHERE username='$u'";
mysqli_query($con, $query);
$c=$row1[0]=1;
$query1 = "insert into book values('$c','$row[1]')";
mysqli_query($con, $query1);
?>
<script type='text/javascript'>alert('Booked');
window.location.assign("main.html")</script>
<?
mysqli_close($con); }
else
{
?>
<script type='text/javascript'>alert('Booking Full or you have already booked');
window.location.assign("main.html")</script>
<?
mysqli_close($con); }
?>

